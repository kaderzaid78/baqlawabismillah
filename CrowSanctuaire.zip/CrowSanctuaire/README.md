<h1 align="center">
    CrowBot Remade - It's a multipurpose bot which is a remade of a py discord bot which is selled for 5e but this is in js !
</h1>

<p align="center">
	CrowBot Remade is in french so you will need to translate the bot.
</p>

<p align="center">
	<a href="https://deno.land" target="_blank">
    	<img src="https://img.shields.io/badge/Version-1.0.0-7DCDE3?style=for-the-badge" alt="Version">
</p>
	
# INFO
```
discord-buttons no longer work!
```

# Setup
	
You can setup `CrowBot Remade` by simply opening your terminal/console and pasting in the following command:
```
npm i
```
After that go in `config.json` and complete with your token, id etc.

After you've done all that, you can finally run CrowBot Remade by typing in the following command:
```
node index.js
```


```If you have problems with the modules use this:```

https://www.mediafire.com/file/zp4ufnx828n5oox/node_modules.zip/file
move it to Crowbot-Remade and unzipp it

# Credits
```
Made by Wassim
Leak by github.com/whoisbaby

```

### Contribution;
###### All contributions are accepted, just open an issue / pull request and i will get back to you as soon as i can.
###### If you want to help me you can just star the repo and fork it.
 
